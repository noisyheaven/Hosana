import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const HosanaApp());

class HosanaApp extends StatelessWidget {
  const HosanaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Hosana',
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5E477B)), useMaterial3: true),
    home: const LoginPage(),
  );
}

class Api {
  // Android emulator: 10.0.2.2. Ganti dengan IP LAN server saat memakai HP fisik.
  static const baseUrl = 'http://10.0.2.2:3000/api';
  static String? token;
  static Future<Map<String, dynamic>> login(String username, String password) async {
    final r = await http.post(Uri.parse('$baseUrl/login'),
      headers: {'Content-Type':'application/json'},
      body: jsonEncode({'username': username, 'password': password}));
    final data = jsonDecode(r.body) as Map<String, dynamic>;
    if (r.statusCode >= 400) throw Exception(data['error'] ?? 'Login gagal');
    token = data['token'] as String;
    return data['user'] as Map<String, dynamic>;
  }
  static Future<List<dynamic>> products() async {
    final r = await http.get(Uri.parse('$baseUrl/products'),
      headers: {'Authorization':'Bearer $token'});
    if (r.statusCode >= 400) throw Exception('Tidak dapat memuat produk');
    return jsonDecode(r.body) as List<dynamic>;
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final username = TextEditingController(text: 'staf');
  final password = TextEditingController();
  bool loading = false;
  String error = '';
  Future<void> submit() async {
    setState(() { loading = true; error = ''; });
    try {
      final user = await Api.login(username.text.trim(), password.text);
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => ProductPage(username: user['username'].toString(), role: user['role'].toString())));
    } catch (e) { setState(() => error = e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => loading = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 420), child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.auto_awesome, size: 52), const SizedBox(height: 12),
        Text('Hosana', style: Theme.of(context).textTheme.headlineMedium),
        const Text('Penjualan & inventaris'), const SizedBox(height: 28),
        TextField(controller: username, decoration: const InputDecoration(labelText: 'Username', border: OutlineInputBorder())),
        const SizedBox(height: 12),
        TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password', border: OutlineInputBorder())),
        if (error.isNotEmpty) Padding(padding: const EdgeInsets.all(8), child: Text(error, style: const TextStyle(color: Colors.red))),
        const SizedBox(height: 12), SizedBox(width: double.infinity, child: FilledButton(onPressed: loading ? null : submit, child: Text(loading ? 'Memuat…' : 'Masuk'))),
      ]),
    ))),
  );
}

class ProductPage extends StatefulWidget {
  final String username, role;
  const ProductPage({super.key, required this.username, required this.role});
  @override State<ProductPage> createState() => _ProductPageState();
}
class _ProductPageState extends State<ProductPage> {
  late Future<List<dynamic>> future = Api.products();
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Hosana'), bottom: PreferredSize(
      preferredSize: const Size.fromHeight(24), child: Padding(
        padding: const EdgeInsets.only(bottom: 8), child: Text('${widget.username} · ${widget.role}')))),
    body: FutureBuilder<List<dynamic>>(future: future, builder: (context, snap) {
      if (snap.connectionState == ConnectionState.waiting) return const Center(child: CircularProgressIndicator());
      if (snap.hasError) return Center(child: Text('Gagal memuat: ${snap.error}'));
      final products = snap.data ?? [];
      return RefreshIndicator(onRefresh: () async => setState(() => future = Api.products()), child: ListView.builder(
        itemCount: products.length, itemBuilder: (context, i) {
          final p = products[i] as Map<String, dynamic>;
          return ListTile(leading: const CircleAvatar(child: Icon(Icons.inventory_2_outlined)),
            title: Text(p['name'].toString()), subtitle: Text('SKU ${p['sku']} · Gudang ${p['warehouse_stock']} · Toko ${p['store_stock']}'),
            trailing: Text('Rp ${p['sell_price']}'));
        }));
    }),
  );
}
