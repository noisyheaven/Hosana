# Android starter (Flutter)

Ini adalah starter Android yang menggunakan REST API website. Untuk menjalankan:
1. Install Flutter SDK dan Android Studio.
2. Buat project Flutter baru (`flutter create hosana_android`), lalu ganti `lib/main.dart` dengan file ini.
3. Tambahkan dependency `http: ^1.2.2` di `pubspec.yaml`, kemudian `flutter pub get`.
4. Jalankan website API di komputer. Emulator Android biasanya dapat mengakses host komputer melalui `http://10.0.2.2:3000`. Untuk HP fisik, gunakan IP LAN komputer, misalnya `http://192.168.1.10:3000`, dan pastikan firewall mengizinkan port 3000.
5. Untuk HTTP lokal Android, konfigurasi cleartext traffic hanya untuk debug. Produksi wajib HTTPS.

Aplikasi ini adalah starter login + daftar produk. Modul kasir, kamera barcode, PO dan laporan dapat dikembangkan di atas API yang sudah tersedia.
