# API ringkas
Semua endpoint selain `/api/login` dan `/api/health` memerlukan header `Authorization: Bearer <token>`.

- `POST /api/login` `{ "username": "...", "password": "..." }`
- `GET /api/dashboard`
- `GET /api/products?search=...`
- `POST /api/products` / `PUT /api/products/:id` / `DELETE /api/products/:id`
- `POST /api/stock/transfer` `{ "product_id": 1, "qty": 3, "from_location": "warehouse", "to_location": "store", "note": "" }`
- `GET /api/stock/moves`
- `POST /api/purchase-orders` `{ "supplier":"...", "notes":"", "items":[{"product_id":1,"qty":10,"unit_cost":12000}] }`
- `GET /api/purchase-orders`, `GET /api/purchase-orders/:id`
- `PUT /api/purchase-orders/:id`, `PUT /api/purchase-orders/:id/items`
- `POST /api/purchase-orders/:id/receive`
- `POST /api/sales` `{ "items":[{"product_id":1,"qty":2}], "payment_method":"cash", "paid":40000, "discount":0 }`
- `GET /api/sales?from=2026-01-01&to=2026-12-31`, `GET /api/sales/:id`
- `GET /api/reports/sales?from=2026-01-01&to=2026-12-31`
- `GET /api/users`, `POST /api/users` (superadmin only)

Role policy: superadmin/admin dapat mengelola barang, stok dan PO; staf dapat melakukan transaksi penjualan; pembuatan user hanya superadmin.
