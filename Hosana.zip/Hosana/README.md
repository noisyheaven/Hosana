# Sistem Toko Asesoris Rohani

Satu sistem terpadu yang **dirancang untuk jaringan lokal tanpa internet**, termasuk **toko dan gudang di gedung terpisah**: satu server dengan satu database, diakses dari kasir (kabel LAN) dan HP/tablet staf (Wi-Fi). Semua perangkat memakai data yang sama, jadi stok toko dan gudang selalu sinkron. Pemasangan dua gedung ada di **bagian 6**.

| Bagian | Alamat (setelah server jalan) | Untuk siapa |
|---|---|---|
| Toko online (opsional) | `http://localhost:3000/` | Pelanggan: lihat barang, pesan, lacak pesanan. Bisa dimatikan di Pengaturan bila sistem hanya dipakai internal |
| Panel kasir & admin | `http://localhost:3000/admin/` | Kasir, staf, gudang, admin, superadmin |

Server tidak butuh pustaka tambahan: hanya **Node.js 22.13 atau lebih baru** (unduh versi LTS di https://nodejs.org).

---

## 1. Menjalankan di komputer (lokal)

1. Ekstrak folder `toko-rohani`.
2. Jalankan server:
   - **Windows:** klik dua kali `start.bat`
   - **Mac/Linux:** `./start.sh` (sekali saja: `chmod +x start.sh`)
   - atau di terminal: `npm start`
3. Buka `http://localhost:3000/admin/` dan masuk dengan akun awal:

| Username | Password | Peran |
|---|---|---|
| `superadmin` | `super123` | Superadmin |
| `admin` | `admin123` | Admin |
| `staf` | `staf123` | Staf kasir |
| `gudang` | `gudang123` | Staf gudang |
| `kasir` | `kasir123` | Kasir (hanya jual-beli) |

**Segera ganti password** (tombol *Ganti password* di kiri bawah, atau superadmin lewat menu *Pengguna & Role*).

Pertama kali jalan, sistem membuat 11 barang contoh. Untuk memulai dengan data kosong: hapus folder `data/`, lalu jalankan dengan `SEED_DEMO=0` (Windows PowerShell: `$env:SEED_DEMO=0; npm start`).

Semua data tersimpan di folder `data/` (database `toko.db` + foto produk). **Backup = salin folder itu**, atau pakai tombol *Unduh backup database* di menu Pengaturan.

## 2. Mencoba dari HP (satu Wi-Fi)

Saat server jalan, terminal menampilkan alamat seperti `http://192.168.1.10:3000/admin/`. Buka di Chrome HP, lalu menu ⋮ → *Tambahkan ke layar utama* (atau tombol *Pasang aplikasi* di panel).

**Kamera untuk scan barcode hanya mau aktif lewat HTTPS.** Jika memakai HP lewat Wi-Fi:

```
npm run cert      # butuh OpenSSL (sudah ada di Mac/Linux & Git for Windows)
npm start         # server otomatis pindah ke https://...
```

Buka `https://192.168.1.10:3000/admin/`; browser akan memperingatkan "tidak aman" (wajar untuk sertifikat buatan sendiri), pilih *Lanjutkan*. Alternatif tanpa peringatan: pasang [mkcert](https://github.com/FiloSottile/mkcert) (perintahnya ditampilkan jika OpenSSL tidak ada).

Tanpa kamera pun scan tetap bisa: **scanner barcode USB/Bluetooth** bekerja seperti keyboard, cukup klik kolom *Scan barcode* di Kasir lalu tembak barangnya.

Scan kamera memakai fitur bawaan browser; untuk browser/WebView yang tidak punya, ada pustaka cadangan. Agar tidak butuh internet: `npm install` lalu `npm run vendor` (sekali saja).

## 3. Peta fitur ke permintaan Anda

| # | Permintaan | Di mana |
|---|---|---|
| 1 | Pemesanan | Toko online → pesanan masuk ke menu **Pemesanan**. Staf juga bisa membuat pesanan dari telepon/WhatsApp. Status: Baru → Diproses → Dikirim → Selesai / Batal. Pelanggan bisa **Lacak pesanan** dengan nomor pesanan + nomor HP |
| 2 | Penjualan | **Kasir** (grid barang, kategori, diskon, uang pas / pecahan cepat, kembalian) dan **Riwayat Penjualan** (batalkan/void dengan alasan, stok otomatis kembali) |
| 3 | Stok barang | **Data Barang** (tambah, edit, hapus/arsip, foto, harga beli & jual, stok minimum) dan **Stok Toko / Gudang** (koreksi, stok opname, riwayat mutasi) |
| 4 | Stok gudang | Stok dipisah per lokasi: toko dan gudang |
| 5 | Scan barcode | Kasir, pencarian barang, PO, transfer, pesanan. Kamera atau scanner USB. Barcode otomatis dibuat (EAN-13) bila kosong, dan bisa **cetak label barcode** |
| 6 | Dashboard (hanya superadmin) | Omzet hari ini/bulan ini, grafik 14 hari, metode bayar, terlaris, stok menipis, pesanan aktif, PO berjalan, nilai stok |
| 7 | Role | Superadmin, Admin, Staf toko, Kasir, Gudang (tabel di bawah) |
| 8 | Purchase order | Menu **Purchase Order** + **Supplier**: draft → diajukan → disetujui → barang diterima (boleh sebagian) |
| 9 | Gudang → toko | Barang dari PO masuk ke **stok gudang**; menu **Transfer Gudang→Toko** memindahkannya ke toko (tercatat, tidak bisa melebihi stok gudang) |
| 10 | Pembayaran | Tunai, QRIS, transfer, debit, COD. Pesanan online dicatat lunas oleh staf setelah uang diterima; tiap pembayaran tercatat |
| 11 | Cetak struk/invoice | Struk 58/80 mm, invoice A4, cetak PO, label barcode |
| 12 | Laporan | **Laporan**: penjualan per hari/metode/kanal/kasir/produk, laba kotor, nilai stok, ekspor CSV (bisa dibuka di Excel) |
| 13 | Revisi PO, tambah/edit/hapus barang | PO bisa **direvisi** (tambah, ubah qty/harga, hapus baris) dengan alasan. Revisi PO yang sudah disetujui kembali ke *Diajukan* untuk disetujui ulang. Setiap revisi tersimpan dengan perbandingan sebelum/sesudah. Barang di PO bisa ditambah, bahkan barang baru yang belum terdaftar |
| 14 | Rekomendasi | Bagian 9 di bawah |

### Cek stok gudang dari toko (menu **Cek Stok**)

Skenario: pelanggan bertanya "patung Bunda Maria ada berapa?". Staf toko membuka **Cek Stok** (menu kiri, bisa dibuka dari HP), lalu:

- menekan **📷 Scan barcode barang**, atau menembak barcode dengan scanner USB/Bluetooth, atau mengetik nama (mis. `patung bunda maria`);
- langsung melihat **dua kotak besar: stok di toko dan stok di gudang**, harga jual, dan keterangan: *Tersedia di toko*, *Stok di toko menipis*, *Habis di toko, ada di gudang*, atau *Habis di toko dan di gudang*;
- bila barang hanya ada di gudang, admin mendapat tombol **Pindahkan dari gudang ke toko**; staf mendapat saran meminta admin memindahkan atau mengambil ke gudang. Bila habis di kedua tempat, staf diarahkan membuat pesanan.

Data diambil langsung dari server saat itu juga, bukan salinan lama. **Harga beli tidak tampil untuk staf.**

**Agar bisa discan, setiap barang harus punya barcode.** Barang berbarcode pabrik: scan sekali di form *Data Barang* agar tercatat. Barang tanpa barcode (patung, rosario curah, dll.): sistem membuat barcode sendiri, lalu cetak labelnya lewat *Data Barang → Label terpilih* dan tempel di barang atau kotaknya. Bila barcode tidak terbaca, ketik namanya.

### Hak akses per peran

| | Kasir | Staf toko | Gudang | Admin | Superadmin |
|---|:--:|:--:|:--:|:--:|:--:|
| **Dashboard** | ✘ | ✘ | ✘ | ✘ | ✔ |
| **Kasir** (jual-beli, cetak struk) | ✔ | ✘ | ✘ | ✔ | ✔ |
| Riwayat penjualan | milik sendiri, 3 hari | ✘ | ✘ | semua | semua |
| Pemesanan (pesanan online/WA) | ✘ | ✔ | ✘ | ✔ | ✔ |
| **Cek Stok** (toko + gudang), lihat barang & stok | ✘ | ✔ | ✔ | ✔ | ✔ |
| **Minta barang ke gudang** & konfirmasi terima di toko | ✘ | ✔ | ✘ | ✔ | ✔ |
| **Proses permintaan toko** (siapkan, kirim, tolak) | ✘ | ✘ | ✔ | ✔ | ✔ |
| **Terima barang dari PO** (tanpa melihat harga beli) | ✘ | ✘ | ✔ | ✔ | ✔ |
| Transfer gudang → toko | ✘ | ✘ | ✔ | ✔ | ✔ |
| Koreksi / opname stok | ✘ | ✘ | gudang saja | ✔ | ✔ |
| Melihat **harga beli** & laba | ✘ | ✘ | ✘ | ✔ | ✔ |
| Tambah/edit/hapus barang | ✘ | ✘ | ✘ | ✔ | ✔ |
| Void penjualan, batalkan pesanan yang sudah dibayar | ✘ | ✘ | ✘ | ✔ | ✔ |
| Purchase order ke supplier (buat/setujui/revisi), supplier, laporan | ✘ | ✘ | ✘ | ✔ | ✔ |
| Kelola pengguna, pengaturan toko, log aktivitas, backup | ✘ | ✘ | ✘ | ✘ | ✔ |

Peran **Kasir** untuk operator transaksi (umumnya di PC kasir): halaman Kasir dan riwayat transaksi miliknya sendiri (tiga hari terakhir). Kasir tidak melihat harga beli, stok gudang, pesanan, atau menu lain. Peran **Staf toko** untuk pelayan pelanggan di lantai toko (umumnya lewat HP di Wi-Fi): halaman awalnya **Cek Stok** (scan atau cari barang, stok toko dan gudang, ketuk barang untuk **detail** foto, harga, deskripsi, kode), melihat data barang, melayani **Pemesanan**, dan **meminta barang ke gudang**. Staf toko tidak berjualan di kasir. Dashboard penjualan hanya untuk superadmin.

Peran **Gudang** dibuat untuk staf di gedung gudang: mereka menerima barang yang PO-nya sudah disetujui admin, memindahkan ke toko, dan menghitung stok gudang, tanpa akses ke penjualan, laporan, atau harga beli. Database lama otomatis dimigrasi saat server dijalankan (data tidak hilang).

Hak akses dijaga di **server**, bukan hanya disembunyikan di tampilan.

### Alur barang yang disarankan

### Permintaan Barang (toko → gudang)

Permintaan internal toko ke gudang, **bukan PO** (PO hanya untuk membeli dari supplier). Menu *Permintaan Barang*, atau tombol **Minta dari gudang** di Cek Stok saat barang habis di toko tapi ada di gudang.

1. **Toko** membuat permintaan (barang, jumlah, catatan, tanda *mendesak*). Tidak perlu persetujuan admin.
2. **Gudang** melihat daftar (halaman awal peran Gudang; daftar menyegarkan diri tiap 20 detik), menekan **Mulai siapkan**, lalu **Kirim** dengan jumlah yang benar-benar dikirim. Bila kurang dari permintaan, wajib isi alasan (mis. stok gudang kurang; permintaan ditandai agar admin membuat PO ke supplier). Gudang juga bisa **Tolak** dengan alasan.
3. **Toko** menekan **Terima barang** dan mengisi jumlah yang sampai. Bila ada selisih, wajib isi catatan; permintaan ditandai *Ada selisih*.

Stok gudang berkurang saat **dikirim**; stok toko bertambah **sebesar yang diterima**. Selama di perjalanan barang tidak tercatat di stok mana pun. Selisih (kirim 10, terima 9) berarti 1 unit hilang dari catatan: periksa lalu koreksi lewat Stok (admin). Pembuat bisa membatalkan selama gudang belum memproses. Seluruh mutasi tercatat di Riwayat Mutasi dengan nomor `REQ-…`.

`PO dibuat → diajukan → disetujui → barang datang (terima ke gudang) → transfer ke toko → dijual di kasir / toko online`

## 4. Menyesuaikan toko

Menu **Pengaturan** (superadmin): nama toko, alamat, nomor WhatsApp (format `62812…`), info rekening dan catatan QRIS (tampil di toko online setelah pelanggan memesan), tulisan kaki struk, lebar kertas, izin jual saat stok 0, dan batas waktu pembatalan otomatis pesanan online.

Foto produk: tambah/edit barang → **📷 Ambil foto (kamera)** untuk memotret langsung dari HP (kamera HP terbuka langsung; tidak butuh HTTPS), atau **🖼 Pilih dari galeri / file** (di PC keduanya membuka pemilih file). Foto otomatis diperkecil sebelum diunggah; tombol *Hapus foto* tersedia. Hanya barang dengan opsi *tampil di toko online* yang muncul di toko online.

## 5. Akses staf: toko dan gudang (web saja)

Tidak ada aplikasi yang dipasang. Semua staf, termasuk di gudang, memakai **browser (Chrome)** di HP atau komputer.

1. **Sambungkan perangkat ke jaringan toko**: Wi-Fi (HP/tablet) atau kabel LAN (komputer). Di gedung gudang, pakai access point gudang yang sudah tersambung ke jaringan server (lihat bagian 6).
2. **Buka alamat server** di Chrome, misalnya `http://192.168.1.10:3000/admin/`. Alamat persisnya ada di **Pengaturan → Alamat akses untuk staf** (superadmin), lengkap dengan tombol *Salin* dan *Cetak kartu alamat* untuk ditempel di gudang. Alamat yang sama tertulis di jendela server saat dijalankan.
3. **Login dengan akun masing-masing** (dibuat superadmin di menu Pengguna & Role; untuk staf gudang pilih peran **Gudang**).
4. **Pasang pintasan**: Chrome ⋮ → *Tambahkan ke layar utama*, supaya terbuka seperti aplikasi.

Agar alamat tidak berubah, atur **DHCP reservation** untuk komputer server di router (bagian 6).

### Scan barcode di gudang: apa yang bisa dan tidak

Browser hanya mengizinkan **kamera** di alamat `https://` atau `localhost`. Di alamat `http://192.168.x.x` biasa, tombol kamera **tidak bisa dipakai** (sudah saya uji: kamera tidak tersedia di alamat IP lewat HTTP, tersedia di `localhost`). Pilihan, dari yang paling mudah:

- **Scanner barcode USB/Bluetooth** (disarankan untuk gudang): bekerja seperti keyboard. Klik kolom cari/scan lalu tembak barcode. Tidak butuh HTTPS atau pengaturan apa pun.
- **Ketik nama atau SKU barang**: selalu bisa sebagai cadangan.
- **HTTPS dari Tailscale (disarankan bila toko memakai Tailscale):** kamera HP aktif tanpa peringatan; lihat bagian 6b.
- **HTTPS lokal** (`npm run cert`, lalu jalankan ulang server): kamera aktif, tetapi tiap HP menampilkan peringatan "koneksi tidak pribadi" yang harus dilewati sekali. *Belum saya uji di HP sungguhan.*
  - *Install ke desktop di PC server:* dengan sertifikat buatan sendiri Chrome tidak menawarkan Install. Isi `LOCAL_HTTP_PORT=3001` di `config.env`, jalankan ulang server, lalu di PC server buka `http://localhost:3001/admin/` dan Install dari situ (HP tetap memakai `https://IP:3000`). Alternatif tanpa Install: Chrome ⋮ → Simpan dan bagikan → Buat pintasan → *Buka sebagai jendela*.
- Scanner kamera cadangan tanpa internet: `npm install` lalu `npm run vendor` sekali (saat ada internet).

Cetak struk/invoice memakai dialog cetak browser (printer yang terpasang di komputer, atau simpan PDF).

## 6. Pemasangan jaringan offline: toko dan gudang beda gedung

> Bila kedua gedung sudah terhubung lewat Tailscale dan masing-masing punya internet, lewati bagian ini dan lihat **6b**.

**Prinsip:** satu server, satu jaringan, tanpa internet. Kedua gedung disambung menjadi **satu jaringan lokal** sehingga HP/komputer di gudang memakai server yang sama dengan kasir di toko. "Toko" dan "Gudang" hanyalah dua lokasi stok di database yang sama, jadi tidak ada proses sinkronisasi: begitu gudang menerima barang PO atau mentransfer ke toko, kasir langsung melihat stoknya. (Dua server terpisah yang disinkronkan sengaja dihindari: bila link putus, kedua stok bisa menyimpang dan sulit dirujukkan.)

```
 GEDUNG TOKO                                        GEDUNG GUDANG
 ┌──────────────────────────────┐   kabel UTP / fiber   ┌─────────────────────────────┐
 │ Komputer SERVER (kabel LAN)  │   atau sepasang radio │ PC gudang (kabel)           │
 │ Router (satu-satunya DHCP)   │◄─ bridge 5 GHz ─────►│ Switch                      │
 │ Switch ── PC kasir (kabel)   │                       │ Access Point ── HP/tablet   │
 │ Access Point ── HP/tablet    │                       │                staf (Wi-Fi) │
 └──────────────────────────────┘                       └─────────────────────────────┘
        semua perangkat satu jaringan yang sama, mis. 192.168.1.x
```

### Peralatan (contoh)

| Kebutuhan | Pilihan |
|---|---|
| Menyambung dua gedung | **Kabel UTP Cat6** (maks. 100 m per segmen; untuk jalur luar ruang pakai kabel outdoor dan pelindung petir), **kabel fiber** untuk jarak lebih jauh, atau **sepasang radio bridge 5 GHz** point-to-point (perlu saling "melihat" tanpa penghalang; contoh seri: TP-Link CPE, Ubiquiti NanoStation/LiteBeam) |
| Wi-Fi staf | Satu *access point* di tiap gedung, disambung kabel ke switch |
| Router | **Satu saja** (di gedung toko), yang membagikan alamat IP |
| Listrik | **UPS** untuk server, router, switch, dan radio bridge di kedua gedung |

### Pilihan menyambung ke gedung gudang

Dua cara yang Anda pertimbangkan sama-sama bisa. Bedanya ada pada kestabilan.

| | **A. Kabel LAN ke access point gudang** | **B. Wi-Fi extender ke access point gudang** |
|---|---|---|
| Kestabilan | Paling stabil dan cepat | Bergantung kuat sinyal; bisa lambat atau putus-putus |
| Kecepatan | Penuh | Sekitar separuh per lompatan (extender satu radio); makin jauh makin turun |
| Biaya & kerja | Beli dan pasang kabel (galian/pipa/tiang) | Murah, tinggal pasang |
| Risiko | Petir dan beda arde antar gedung bila kabel tembaga lewat luar | Terganggu dinding beton/logam, hujan, jarak, dan Wi-Fi lain |
| Cocok untuk | Pemakaian harian, HP/tablet scan gudang yang terus bekerja | Mencoba dulu, atau jarak pendek dengan sinyal sangat kuat |

**Opsi A, hal yang perlu diperhatikan**
- Kabel UTP Cat6 **maksimal 100 m** per segmen. Jalur luar ruang: kabel **outdoor** (tahan UV, berpelindung), lewat pipa, dengan **surge protector** di kedua ujung.
- Jika jaraknya lebih dari 100 m, atau kedua gedung beda arde/jaringan listrik, pakai **fiber + media converter**, atau sepasang **radio bridge** (secara fungsi seperti "extender" kelas profesional, pakai antena terarah, jauh lebih stabil antar gedung).
- Access point di gudang sebaiknya **PoE** (satu kabel untuk data dan listrik), dalam mode Access Point, tanpa DHCP.

**Opsi B, hal yang perlu diperhatikan**
- Letakkan extender di titik yang **masih menerima sinyal toko dengan kuat** (di HP minimal 3 dari 4 batang). Extender hanya memperkuat yang diterimanya; menaruhnya di titik yang sudah lemah hasilnya buruk.
- Pakai band **5 GHz** bila ada (lebih cepat, lebih sepi), dan jauhkan dari logam serta dinding tebal.
- Bila extender punya port LAN dan mode **Client/Bridge**, sambungkan ke access point gudang dengan kabel pendek, itu lebih stabil daripada staf gudang langsung memakai Wi-Fi hasil pantulan.
- Usahakan tetap **satu jaringan** (mode Repeater/Bridge), bukan mode Router. Subnet terpisah biasanya tetap bisa mengakses server karena HP-lah yang memulai sambungan, tetapi server melihat semua HP sebagai satu alamat dan perangkat lebih sulit saling menemukan.

**Uji kelayakan 15 menit sebelum dipasang permanen (khusus opsi B, dan juga berguna untuk A)**
1. Berdirilah di titik gudang tempat staf bekerja, sambungkan laptop atau HP ke Wi-Fi gudang.
2. Windows: `ping -n 200 192.168.1.10` · Mac/Linux: `ping -c 200 192.168.1.10` (ganti dengan IP server).
3. Lihat ringkasannya. Patokan yang wajar untuk aplikasi ini: **kehilangan paket 0 sampai 1%**, rata-rata **di bawah 50 ms**, dan tidak ada lonjakan di atas 300 ms. Ini patokan praktis dari saya, bukan hasil pengukuran di lokasi Anda.
4. Buka panel dan perhatikan lencana di pojok kanan atas: **hijau "terhubung · 26 ms"** = baik, **kuning** = lambat (di atas 400 ms), **merah dan banner "server tidak terjangkau"** = putus.
5. Lakukan di jam sibuk, juga saat banyak perangkat aktif. Jika hasilnya sering kuning atau merah, naikkan ke opsi A atau radio bridge.

**Saran:** mulai dari opsi B untuk mencoba bila anggaran terbatas; bila lolos uji dan stabil, boleh dipertahankan. Untuk pemakaian jangka panjang (apalagi tablet scan di gudang yang bekerja terus), opsi A atau radio bridge jauh lebih aman.

### Langkah pemasangan

1. **Satukan jaringan.** Sambungkan gedung gudang ke jaringan toko dengan salah satu cara di atas (opsi A, B, atau radio bridge). Perangkat penghubung (radio bridge, access point) harus diatur ke mode **Bridge / Access Point**, **bukan Router**.
2. **Satu pembagi IP saja.** Hanya router di toko yang menjalankan DHCP. Matikan DHCP di access point dan radio bridge. Semua perangkat akhirnya satu rentang, mis. `192.168.1.x`.
3. **Matikan "AP Isolation / Client Isolation"** di pengaturan Wi-Fi, agar HP bisa menjangkau server. (Jaringan "tamu" biasanya terisolasi; jangan dipakai.)
4. **Server di kabel LAN** (bukan Wi-Fi), disambung ke switch/router di toko. Di router buat **DHCP reservation / alamat tetap**, mis. `192.168.1.10`, supaya alamat server tidak berubah.
5. **Windows Firewall:** saat pertama menjalankan server, centang **Private networks** → *Allow access*. Jika terlewat: Windows Security → Firewall → *Allow an app* → Node.js.
6. **Jalankan server:** klik `start.bat` (atau `npm start`). Alamat yang dipakai staf tampil di terminal, mis. `http://192.168.1.10:3000/admin/`.
7. **Uji dari gudang:** HP di Wi-Fi gudang membuka alamat itu dan masuk. Jika gagal: periksa langkah 1 sampai 5 (penyebab terbanyak: DHCP ganda dan Client Isolation).
8. **Hidup otomatis:** tekan `Win+R`, ketik `shell:startup`, taruh *shortcut* `start.bat` di folder itu. Atur komputer agar tidak sleep.

> Jika Wi-Fi memakai router kedua dalam mode Router (NAT), server melihat semua HP sebagai satu alamat. Sistem sudah menghitung batas login per akun sehingga satu orang salah ketik tidak mengunci semua orang, tetapi tetap lebih rapi memakai mode Access Point.

### Server ditaruh di mana?

Taruh di **gedung toko**: transaksi kasir terjadi terus-menerus dan itu yang paling tidak boleh berhenti. Bila link ke gudang putus, toko tetap berjalan normal dan hanya pekerjaan gudang yang menunggu.

### Backup ke gedung lain (jangan dilewatkan)

Server adalah satu-satunya tempat data berada. Jika komputernya rusak atau toko kemalingan, semua data ikut hilang. Karena itu server bisa **membuat backup otomatis ke komputer di gedung gudang**.

1. Di PC gudang: buat folder `backup-toko`, klik kanan → *Properties* → *Sharing*, beri akses tulis untuk akun yang dipakai.
2. Di komputer server: salin `config.env.example` menjadi `config.env`, lalu isi `BACKUP_DIR=\\GUDANG-PC\backup-toko` (atau `E:\backup-toko` untuk flashdisk). Jalankan ulang server.
3. Backup dibuat saat server menyala lalu tiap 6 jam; 30 file terbaru disimpan. **Pengaturan → Cadangan data** menampilkan *Backup otomatis aktif* atau tanda merah **Backup GAGAL** beserta alasannya (mis. PC gudang mati).
4. **Pemulihan:** matikan server, buka folder `data/`, hapus `toko.db`, `toko.db-wal`, dan `toko.db-shm`, salin file backup pilihan ke sana dengan nama `toko.db`, lalu jalankan server.

Uji sekali setelah dipasang: lihat apakah file `.db` muncul di PC gudang. Backup yang belum pernah dites pemulihannya belum bisa dianggap aman.

### Jam dan listrik

Tanpa internet, jam komputer server tidak sinkron otomatis. **Semua waktu transaksi memakai jam server**, jadi cek tanggal dan jam server tiap bulan. Pakai UPS agar listrik padam tidak merusak database atau memutus link antar gedung.

### Bila link antar gedung atau Wi-Fi putus

- Di perangkat yang terputus, dalam ±8 detik muncul **banner merah "Sambungan ke server terputus"** dan lencana *server tidak terjangkau*; isian di layar tidak hilang. Setelah tersambung lagi banner hilang sendiri; tekan Bayar / Simpan lagi.
- Tidak ada transaksi setengah jalan yang tersimpan: tiap penyimpanan bersifat atomik.
- Kasir di gedung server tidak terpengaruh. Gudang berhenti sementara; catat di kertas dan input setelah tersambung.
- **Belum ada mode offline untuk perangkat yang kehilangan server.** Karena itu kualitas link antar gedung adalah hal terpenting dalam pemasangan ini.

### Akses dari HP tanpa internet

- *Pintasan Chrome* (⋮ → Tambahkan ke layar utama): paling sederhana, tetapi **kamera scan tidak aktif** di alamat `http://` biasa. Gunakan scanner barcode USB/Bluetooth atau ketik kode.
- *HTTPS lokal* (`npm run cert`): kamera aktif di browser, tetapi tiap HP memberi peringatan "tidak aman".
- Scanner kamera cadangan tanpa internet: jalankan `npm install` lalu `npm run vendor` sekali (saat ada internet).

### Jika kedua gedung tidak bisa disambung

Tanpa kabel/radio antar gedung, dua lokasi **tidak bisa saling terhubung secara real-time**. Fitur untuk kondisi itu (server kedua di gudang, transfer barang lewat berkas/flashdisk) **belum ada**; kabari saya bila ini yang terjadi.

### Toko online

Halaman pelanggan hanya terjangkau di jaringan lokal. Jika sistem hanya dipakai staf, matikan di **Pengaturan → Aktifkan halaman toko online**; alamat `/` lalu langsung diarahkan ke panel admin.

## 6b. Skenario toko ini: Tailscale, tiap gedung punya internet sendiri

Kondisi: PC toko dan PC gudang sudah terhubung lewat Tailscale, dan tiap gedung punya internetnya sendiri (tidak ada kabel/radio antar gedung). Maka **bagian 6 (kabel, extender, radio) tidak diperlukan**: Tailscale-lah penghubung kedua gedung. Aplikasi ini jalan di **satu PC server** (sebaiknya PC toko yang menyala sepanjang hari), dan semua perangkat lain membukanya dari browser.

```
 PC gudang ──┐                          ┌── HP staf toko (aplikasi Tailscale)
 HP staf gudang ─ (Tailscale) ─ PC SERVER (toko) ─ (Tailscale) ──┘
```

### Langkah pasang (sekali saja)
1. **Server:** pasang aplikasi ini di PC server (bagian 1), pastikan Tailscale di PC itu sudah login.
2. **Aktifkan HTTPS Tailscale** (supaya kamera HP bisa dipakai): di https://login.tailscale.com/admin/dns aktifkan **MagicDNS**, lalu **Enable HTTPS**.
3. **Jalankan `npm run tailscale`** di PC server. Perintah ini membaca status Tailscale dan mencetak persis apa yang perlu dijalankan: `tailscale serve --bg 3000` dan dua baris untuk `config.env` (`TRUST_PROXY=1`, `PUBLIC_HOST=…`). Jalankan ulang server setelahnya.
4. **PC gudang dan HP staf:** pasang Tailscale, login ke akun tailnet toko, lalu buka `https://NAMA-SERVER.nama-tailnet.ts.net/admin/`. Alamat persisnya juga tampil di **Pengaturan → Alamat akses untuk staf**; tombol *Cetak kartu alamat* membuat lembar petunjuk untuk staf.
5. Di HP: Chrome ⋮ → *Tambahkan ke layar utama*. Di PC: pintasan atau *Install* dari Chrome.

Dengan alamat `https://…ts.net` sertifikatnya sah, jadi **tidak ada peringatan dan kamera scan di HP bekerja**. Di PC, scanner USB/Bluetooth tetap cara tercepat.

**Scanner kamera di HP:** Chrome Android punya pembaca barcode bawaan. iPhone/Safari memakai pustaka cadangan: jalankan `npm install` lalu `npm run vendor` sekali di PC server agar pustaka ikut dilayani dari server (tanpa itu diambil dari internet).

### Yang perlu dipahami
- **Butuh internet di kedua sisi.** Tailscale menghubungkan lewat internet. Bila internet toko mati, gudang tidak bisa membuka aplikasi (kasir di PC server tetap jalan lewat `http://localhost:3000`). Bila internet gudang mati, hanya gudang yang terputus. Menurut [dokumentasi Tailscale](https://tailscale.com/docs/reference/coordination-server-down.md), bila hanya server koordinasi Tailscale yang tak terjangkau, koneksi yang sudah ada tetap jalan selama kunci perangkat belum kedaluwarsa.
- **Backup** tetap penting: isi `BACKUP_DIR` (bagian 6, "backup ke gedung lain") dengan folder bersama di PC gudang lewat alamat Tailscale, atau unduh manual dari Pengaturan.
- Sertifikat dari `tailscale serve` umumnya diperbarui otomatis oleh Tailscale (periksa saat mendekati 90 hari). Alternatif manual `tailscale cert` (isi `TLS_CERT`/`TLS_KEY` di `config.env`) berlaku 90 hari dan harus diperbarui sendiri.
- Sertifikat HTTPS Tailscale tercatat di log publik (Certificate Transparency) **beserta nama komputer**. Beri nama komputer yang netral.
- Jangan memakai *Tailscale Funnel* (membuka server ke internet umum). Atur ACL agar hanya perangkat toko yang bisa menjangkau server. Login aplikasi tetap wajib; ada pembatas percobaan login per perangkat.
- Jumlah perangkat/pengguna yang boleh di paket Tailscale Anda mengikuti ketentuan Tailscale; periksa di panel adminnya bila HP staf banyak.
- Port 3000 bisa diganti lewat `PORT=` di `config.env` bila bentrok dengan aplikasi lain di PC yang sama.
- **Belum diuji dengan Tailscale sungguhan.** Yang sudah diuji: sisi aplikasi (HTTPS dari file sertifikat, `HOST`, `TRUST_PROXY`, pembacaan status). Perintah `tailscale serve` dan format keluaran `tailscale status --json` mengikuti dokumentasi Tailscale dan perlu dicoba di PC toko. Bila `npm run tailscale` gagal membaca, jalankan `tailscale serve --bg 3000` sendiri dan isi `config.env` manual.

## 7. Lupa password / akun terkunci

Password disimpan di database (folder `data/`), bukan di kode. Server yang mulai dengan folder `data/` kosong membuat ulang akun awal (`superadmin/super123`, `admin/admin123`, `staf/staf123`, `gudang/gudang123`, `kasir/kasir123`).

Lupa password atau akun terkunci: di komputer server, jalankan
```
node scripts/reset-password.js --list                    # lihat akun
node scripts/reset-password.js superadmin PasswordBaru1  # reset (min. 6 karakter)
```
Akun yang terkunci ("terlalu banyak percobaan") terbuka sendiri setelah 10 menit atau bila server dijalankan ulang.

**Lampiran: memasang di internet (tidak dipakai pada mode offline).** Aplikasi ini server Node.js dengan database di disk, jadi **tidak bisa** dipasang di Cloudflare Pages/Workers (hanya untuk situs statis; gejalanya login menampilkan "Terjadi kesalahan"). Jika suatu saat perlu, pakai Cloudflare Tunnel ke server Anda atau VPS dengan disk tetap, dan jalankan dengan `TRUST_PROXY=1` di `config.env`. Pasang HTTPS dan ganti semua password.

## 8. Keamanan dan pengujian

- Password disimpan ter-hash (scrypt), sesi berlaku 7 hari, login dibatasi 10 percobaan gagal per 10 menit untuk tiap kombinasi perangkat + akun.
- Pesanan online dibatasi 8 per 10 menit per perangkat (ubah dengan `ORDER_LIMIT`).
- **Pesanan online yang belum dibayar otomatis dibatalkan setelah 24 jam** dan stok dikembalikan (COD dan pesanan yang sudah diproses tidak disentuh; atur jamnya di Pengaturan, `0` untuk mematikan).
- Setiap aksi penting masuk **Log aktivitas** (siapa, apa, kapan).
- Pengujian otomatis: `npm test` (170 pemeriksaan: 53 API termasuk hak akses, stok, PO, pesanan, laporan; 24 untuk pengaman, backup otomatis, dan konfigurasi; 29 untuk peran Gudang dan migrasi database lama; 12 untuk konfigurasi Tailscale/HTTPS; 25 untuk Permintaan Barang; 28 untuk peran Kasir, Staf toko, dan dashboard). Alur tampilan (4 peran, semua halaman, kasir, siklus PO penuh, toko online, banner server terputus, Cek Stok sebagai staf di layar HP) juga sudah diuji di Chromium. `npm test` bagian API butuh `bash` (Windows: Git Bash atau WSL).
- **Belum diuji dengan perangkat nyata:** kamera untuk scan (termasuk HTTPS lokal di HP), printer, dan pemasangan jaringan dua gedung (radio bridge, access point, folder bersama di PC gudang) karena itu bergantung pada perangkat di lokasi Anda.

## 9. Rekomendasi

**Sebelum dipakai sungguhan**
1. Ganti ketiga password awal dan isi data toko (nama, WhatsApp, rekening) di Pengaturan.
2. Aktifkan **backup otomatis ke gedung lain** (bagian 6) dan uji pemulihannya sekali. Cadangan tambahan ke flashdisk mingguan juga baik.
3. Pasang **UPS** untuk server dan perangkat jaringan di kedua gedung.
4. Lakukan **stok opname awal** (menu Stok → koreksi, mode "set") sebelum mulai berjualan, lalu cetak label barcode untuk barang yang belum punya barcode.

**Pengembangan berikutnya (urut manfaat)**
- **Pembayaran otomatis** (Midtrans/Xendit) agar QRIS/transfer online lunas tanpa dicek manual. Saat ini pembayaran dicatat manual oleh staf.
- **Ongkos kirim** (RajaOngkir/Biteship) dan nomor resi.
- **Notifikasi WhatsApp** ke pelanggan saat status pesanan berubah.
- **Varian barang** (ukuran cincin, warna): saat ini tiap varian dibuat sebagai barang terpisah dengan SKU sendiri.
- **Retur/refund sebagian**, hutang ke supplier, dan promo/diskon per barang.
- **Data pelanggan & poin loyalitas**, terutama jika banyak pembeli langganan.
- **Mode offline kasir** bila listrik/Wi-Fi sering putus.
- Jika kelak ada lebih dari satu cabang: tambahkan lokasi stok per cabang (struktur stok sudah per-lokasi).

## 10. Struktur folder

```
toko-rohani/
├─ server.js, db.js        server & database (SQLite bawaan Node)
├─ config.env.example      contoh pengaturan server (salin jadi config.env)
├─ public/index.html …     toko online pelanggan
├─ public/admin/           panel kasir & admin (PWA)
├─ tests/                  pengujian otomatis
├─ scripts/                sertifikat HTTPS, pustaka scanner, pembaca status Tailscale, reset password
└─ data/                   dibuat otomatis: database & foto (JANGAN dihapus)
```

Pengaturan server cukup ditulis di `config.env` (lihat `config.env.example`): `PORT` (default 3000), `DATA_DIR`, `BACKUP_DIR`, `BACKUP_EVERY_HOURS`, `BACKUP_KEEP`, `SEED_DEMO=0`, `HTTPS=0`, `ORDER_LIMIT`, `TRUST_PROXY=1`.
